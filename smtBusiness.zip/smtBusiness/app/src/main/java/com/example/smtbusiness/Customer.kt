package com.example.smtbusiness

data class Customer (
    val id: Int,
    var name: String,
    var email: String,
    var mobile: String
)
